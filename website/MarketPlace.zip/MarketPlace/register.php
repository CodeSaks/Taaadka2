<?php require "/Users/spartan/Desktop/Sems/Fall 2023/RS 272/folder/Taaadka2/website/MarketPlace" ?>
<?php

$sql = "INSERT INTO signup (firstName,lastName,email,address,phone,password) VALUES ('" . $_POST["firstName"] . "', '" . $_POST["lastName"] . "', '" . $_POST["email"] . "', '" . $_POST["address"] . "', '" . $_POST["phone"] . "', '" . $_POST["password"] . "')";
$conn->query($sql);
$conn->close();
header("location: loginPage.php");

?>