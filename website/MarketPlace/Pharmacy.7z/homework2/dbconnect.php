<?php
$servername = "db272.cv99a47vgyml.us-west-1.rds.amazonaws.com";
$username = "admin";
$password = "password";
$dbname = "cmpe272";
$conn = new mysqli($servername, $username, $password, $dbname,3306);
?>
