<?php
echo "<h2>PHP is Fun, This is Prabhat site!</h2>";
echo "Hello world!<br>";
echo "I'm about to learn PHP! Hurray!!<br>";
echo "This ", "string ", "was ", "made ", "with multiple parameters.";
?>
